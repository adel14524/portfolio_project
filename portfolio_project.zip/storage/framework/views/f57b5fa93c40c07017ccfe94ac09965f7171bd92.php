<p class="p-3"><h2>Hello Adilah,</h2></p>
<br>
<p class="p-3">You have received an email from <?php echo e($name); ?></p>
<p>Here's the details : </p>
<br>
<p class="p-3"><b>Name : </b><?php echo e($name); ?></p>
<p class="p-3"><b>Email : </b><?php echo e($email); ?></p>
<p class="p-3"><b>Subject : </b><?php echo e($subject); ?></p>
<p class="p-3"><b>Message : </b><?php echo e($user_message); ?></p>
<br>
<p class="p-3">Thank You</p><?php /**PATH C:\laragon\www\portfolio_project\resources\views/email/contact-email.blade.php ENDPATH**/ ?>