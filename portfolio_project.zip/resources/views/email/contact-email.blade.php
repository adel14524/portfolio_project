<p class="p-3"><h2>Hello Adilah,</h2></p>
<br>
<p class="p-3">You have received an email from {{ $name }}</p>
<p>Here's the details : </p>
<br>
<p class="p-3"><b>Name : </b>{{ $name }}</p>
<p class="p-3"><b>Email : </b>{{ $email }}</p>
<p class="p-3"><b>Subject : </b>{{ $subject }}</p>
<p class="p-3"><b>Message : </b>{{ $user_message }}</p>
<br>
<p class="p-3">Thank You</p>